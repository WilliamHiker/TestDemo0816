package com.toocms.www.testframeforwzw.app;

public enum  ConfigType {
    API_HOST,
    APPLICATION_CONTENT,
    CONFIG_READY,
    ICON
}
