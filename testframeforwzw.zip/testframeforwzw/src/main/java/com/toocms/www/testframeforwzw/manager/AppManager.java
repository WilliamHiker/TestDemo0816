package com.toocms.www.testframeforwzw.manager;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;

import java.util.Iterator;
import java.util.Stack;

public class AppManager {
    public static Object instance;
    private static Stack<Activity> mActivityStack;
    private static AppManager mAppManager;

    private AppManager() {

    }

    public static AppManager getInstance() {
        if (mAppManager == null) {
            mAppManager = new AppManager();
        }
        return mAppManager;
    }

    public void addActivity(Activity activity) {
        if (mActivityStack == null) {
            mActivityStack = new Stack<>();
        }
        mActivityStack.add(activity);
    }

    public Activity getTopActivity() {
        Activity activity = (Activity) mActivityStack.lastElement();
        return activity;
    }

    public void killTopActivity() {
        Activity activity = (Activity) mActivityStack.lastElement();
        this.killActivity(activity);
    }

    public void killActivity(Activity activity) {
        if (activity != null) {
            mActivityStack.remove(activity);
            activity.finish();
            activity = null;
        }
    }

    public void killActivity(Class<?> cls) {
        Iterator iterator = mActivityStack.iterator();
        while (iterator.hasNext()) {
            Activity activity = (Activity) iterator.next();
            if (activity.getClass().equals(cls)) {
                iterator.remove();
                activity.finish();
                activity = null;
            }
        }
    }

    public void killAllActivity() {
        int i = 0;
        for (int size = mActivityStack.size(); i < size; ++i) {
            if (null != mActivityStack.get(i)) {
                ((Activity) mActivityStack.get(i)).finish();
            }
        }
        mActivityStack.clear();
    }

    public void AppExit(Context context) {
        try {
            this.killAllActivity();
            ActivityManager activityMgr = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
            activityMgr.restartPackage(context.getPackageName());
            System.exit(0);
        } catch (Exception e) {
            ;
        }
    }
}
